using ClimateControlReliability;

namespace ClimateControlApi;

public sealed class InMemoryClimateStore : IClimateStore
{
    private readonly List<ClimateMessage> _records = [];
    private readonly object _sync = new();

    public void Save(ClimateMessage message)
    {
        lock (_sync) _records.Add(message);
    }

    public ClimateMessage[] GetAll()
    {
        lock (_sync) return [.. _records];
    }
}
