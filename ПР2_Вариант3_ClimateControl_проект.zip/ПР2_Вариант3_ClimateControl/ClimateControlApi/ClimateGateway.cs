using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace ClimateControlReliability;

public sealed class ClimateGateway(byte[] signingKey, IClimateStore store)
{
    private readonly byte[] _key = (byte[])signingKey.Clone();
    private readonly Queue<ClimateMessage> _pending = new();
    private readonly HashSet<string> _seen = new(StringComparer.Ordinal);

    public int PendingCount => _pending.Count;
    public int RejectedCount { get; private set; }

    public byte[] Sign(ClimateMessage message)
    {
        string payload = string.Join("|", message.SensorId,
            message.TemperatureMilliCelsius.ToString(CultureInfo.InvariantCulture),
            message.TimestampUnixSeconds.ToString(CultureInfo.InvariantCulture));
        return HMACSHA256.HashData(_key, Encoding.UTF8.GetBytes(payload));
    }

    public IngestResult Ingest(ClimateMessage message, long now)
    {
        string id = $"{message.SensorId}:{message.TimestampUnixSeconds}";
        bool valid = message.SensorId is "room-101" or "room-202"
            && message.TemperatureMilliCelsius is >= -40_000 and <= 85_000
            && message.TimestampUnixSeconds >= now - 300
            && message.TimestampUnixSeconds <= now + 30
            && message.Signature is { Length: 32 }
            && CryptographicOperations.FixedTimeEquals(Sign(message), message.Signature);

        if (!valid || !_seen.Add(id))
        {
            RejectedCount++;
            return IngestResult.Rejected;
        }

        try
        {
            store.Save(message);
            return IngestResult.Stored;
        }
        catch (IOException)
        {
            _pending.Enqueue(message);
            return IngestResult.Queued;
        }
    }

    public int FlushPending()
    {
        int saved = 0;
        while (_pending.TryPeek(out ClimateMessage? message))
        {
            try
            {
                store.Save(message);
                _pending.Dequeue();
                saved++;
            }
            catch (IOException)
            {
                break;
            }
        }
        return saved;
    }
}
