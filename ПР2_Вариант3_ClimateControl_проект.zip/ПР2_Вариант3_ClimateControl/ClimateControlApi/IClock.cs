namespace ClimateControlApi;

public interface IClock
{
    long UnixTimeSeconds { get; }
}

public sealed class SystemClock : IClock
{
    public long UnixTimeSeconds => DateTimeOffset.UtcNow.ToUnixTimeSeconds();
}
