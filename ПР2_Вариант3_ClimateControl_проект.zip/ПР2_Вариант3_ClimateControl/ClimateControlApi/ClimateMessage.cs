namespace ClimateControlReliability;

public sealed record ClimateMessage(
    string SensorId,
    int TemperatureMilliCelsius,
    long TimestampUnixSeconds,
    byte[] Signature);

public enum IngestResult
{
    Stored,
    Queued,
    Rejected
}

public interface IClimateStore
{
    void Save(ClimateMessage message);
}
