using System.Text;
using ClimateControlApi;
using ClimateControlReliability;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<InMemoryClimateStore>();
builder.Services.AddSingleton<IClimateStore>(sp => sp.GetRequiredService<InMemoryClimateStore>());
builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton(sp => new ClimateGateway(
    Encoding.UTF8.GetBytes(builder.Configuration["ClimateSigningKey"] ?? "pr6-demo-key-classroom"),
    sp.GetRequiredService<IClimateStore>()));

var app = builder.Build();

app.MapPost("/api/v1/climate/readings", (ClimateReadingRequest request, ClimateGateway gateway, IClock clock) =>
{
    var message = new ClimateMessage(
        request.SensorId,
        request.TemperatureMilliCelsius,
        request.TimestampUnixSeconds,
        request.Signature!);
    var result = gateway.Ingest(message, clock.UnixTimeSeconds);
    return result switch
    {
        IngestResult.Stored => Results.Created("/api/v1/climate/readings", new { status = "Stored" }),
        IngestResult.Queued => Results.Accepted(value: new { status = "Queued" }),
        _ => Results.BadRequest(new { status = "Rejected" })
    };
});

app.MapGet("/api/v1/climate/readings", (InMemoryClimateStore store) =>
    Results.Ok(store.GetAll().Select(x => new { x.SensorId, x.TemperatureMilliCelsius, x.TimestampUnixSeconds })));

app.Run();

public sealed record ClimateReadingRequest(
    string SensorId,
    int TemperatureMilliCelsius,
    long TimestampUnixSeconds,
    byte[]? Signature);

public partial class Program;
