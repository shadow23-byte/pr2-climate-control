using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Xunit;

namespace ClimateControlApi.Tests;

public sealed class ClimateApiTests
{
    private const string Route = "/api/v1/climate/readings";
    private static readonly byte[] Key = Encoding.UTF8.GetBytes("pr6-demo-key-classroom");

    private static ClimateReadingRequest Signed(
        int temperature = 22_500, long? timestamp = null, string sensor = "room-101")
    {
        long time = timestamp ?? DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var payload = $"{sensor}|{temperature}|{time}";
        byte[] signature = HMACSHA256.HashData(Key, Encoding.UTF8.GetBytes(payload));
        return new ClimateReadingRequest(sensor, temperature, time, signature);
    }

    [Fact]
    public async Task ValidReading_IsStoredAndReturnedByGet()
    {
        using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        var reading = Signed();

        var response = await client.PostAsJsonAsync(Route, reading);
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        var stored = await client.GetFromJsonAsync<StoredReading[]>(Route);
        stored.Should().ContainSingle().Which.TemperatureMilliCelsius.Should().Be(reading.TemperatureMilliCelsius);
    }

    [Fact]
    public async Task TamperedTemperature_IsRejectedWithoutSaving()
    {
        using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        var signed = Signed();
        var altered = signed with { TemperatureMilliCelsius = signed.TemperatureMilliCelsius + 1_000 };

        (await client.PostAsJsonAsync(Route, altered)).StatusCode.Should().Be(HttpStatusCode.BadRequest);
        (await client.GetFromJsonAsync<StoredReading[]>(Route)).Should().BeEmpty();
    }

    [Theory]
    [InlineData(-40_000, HttpStatusCode.Created)]
    [InlineData(85_000, HttpStatusCode.Created)]
    [InlineData(-40_001, HttpStatusCode.BadRequest)]
    [InlineData(85_001, HttpStatusCode.BadRequest)]
    public async Task TemperatureBoundary_HasExpectedResult(int temperature, HttpStatusCode expected)
    {
        using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        (await client.PostAsJsonAsync(Route, Signed(temperature))).StatusCode.Should().Be(expected);
    }

    [Theory]
    [InlineData(-300, HttpStatusCode.Created)]
    [InlineData(30, HttpStatusCode.Created)]
    [InlineData(-301, HttpStatusCode.BadRequest)]
    [InlineData(31, HttpStatusCode.BadRequest)]
    public async Task TimestampBoundary_HasExpectedResult(int offsetSeconds, HttpStatusCode expected)
    {
        const long now = 1_800_000_000;
        using var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
            builder.ConfigureServices(services =>
            {
                services.RemoveAll<IClock>();
                services.AddSingleton<IClock>(new FixedClock(now));
            }));
        using var client = factory.CreateClient();
        (await client.PostAsJsonAsync(Route, Signed(timestamp: now + offsetSeconds))).StatusCode.Should().Be(expected);
    }

    [Fact]
    public async Task NullSignature_IsRejectedWithoutServerError()
    {
        using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        var unsigned = Signed() with { Signature = null };
        (await client.PostAsJsonAsync(Route, unsigned)).StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Replay_IsRejectedAndDoesNotDuplicateRecord()
    {
        using var factory = new WebApplicationFactory<Program>();
        using var client = factory.CreateClient();
        var reading = Signed();
        (await client.PostAsJsonAsync(Route, reading)).StatusCode.Should().Be(HttpStatusCode.Created);
        (await client.PostAsJsonAsync(Route, reading)).StatusCode.Should().Be(HttpStatusCode.BadRequest);
        (await client.GetFromJsonAsync<StoredReading[]>(Route)).Should().ContainSingle();
    }

    [Fact]
    public async Task SeparateApplicationInstances_HaveIsolatedStores()
    {
        using var first = new WebApplicationFactory<Program>();
        using var second = new WebApplicationFactory<Program>();
        using var clientA = first.CreateClient();
        using var clientB = second.CreateClient();
        (await clientA.PostAsJsonAsync(Route, Signed())).StatusCode.Should().Be(HttpStatusCode.Created);
        (await clientA.GetFromJsonAsync<StoredReading[]>(Route)).Should().ContainSingle();
        (await clientB.GetFromJsonAsync<StoredReading[]>(Route)).Should().BeEmpty();
    }

    private sealed record StoredReading(string SensorId, int TemperatureMilliCelsius, long TimestampUnixSeconds);
    private sealed record FixedClock(long UnixTimeSeconds) : IClock;
}
