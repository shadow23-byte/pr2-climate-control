using System.Text;
using ClimateControlReliability;
using FluentAssertions;
using Xunit;

namespace ClimateControlApi.Tests;

public sealed class ClimateGatewayUnitTests
{
    private const long Now = 1_800_000_000;

    [Fact]
    public void ValidSignature_StoresMessage()
    {
        var store = new FakeStore();
        var gateway = new ClimateGateway(Encoding.UTF8.GetBytes("unit-test-key"), store);
        var unsigned = new ClimateMessage("room-101", 22_500, Now, []);
        var signed = unsigned with { Signature = gateway.Sign(unsigned) };

        gateway.Ingest(signed, Now).Should().Be(IngestResult.Stored);
        store.Records.Should().ContainSingle().Which.Should().Be(signed);
    }

    [Fact]
    public void NullSignature_ReturnsRejectedWithoutSaving()
    {
        var store = new FakeStore();
        var gateway = new ClimateGateway(Encoding.UTF8.GetBytes("unit-test-key"), store);
        var malformed = new ClimateMessage("room-101", 22_500, Now, null!);

        gateway.Ingest(malformed, Now).Should().Be(IngestResult.Rejected);
        store.Records.Should().BeEmpty();
    }

    private sealed class FakeStore : IClimateStore
    {
        public List<ClimateMessage> Records { get; } = [];
        public void Save(ClimateMessage message) => Records.Add(message);
    }
}
